def checkVowel(string1):
   
    if string1 in "a" "e"  "i"  "o"  "u":
        print('I am in IF',string1)
        return string1," is a vowel"
    else:
        return "it is a Consonant"

def main():
    print("Enter the String")
    string1=input()
    print(type(string1))
    checkv=checkVowel(string1)
    print(checkv)
if __name__=="__main__":
    main()