def Area(no1,no2):
      return no1*no2
def Perimter(no1,no2):
     return 2 * (no1+no2)
def main():
    print("Enter the Length")
    no1=float(input())
    print("Enter the Width")
    no2=float(input())

    ans=Area(no1,no2)
    print("Area",ans)
    per=Perimter(no1,no2)
    print("Perimeter",per)
if __name__=="__main__":
    main()