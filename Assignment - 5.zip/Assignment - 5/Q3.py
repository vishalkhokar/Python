def CheckVoter(no1):
        if no1<18:
             print("Not eligible to vote")
        else :
             print("Eligible to vote")     

def main():
    print("Enter the Number")
    no1=int(input())
    CheckVoter(no1)
if __name__=="__main__":
    main()