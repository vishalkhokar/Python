def Maximun(no1,no2,no3):
        if no1>no2 and no1>no3:
            return no1," is Greater"
        elif no2>no3:
             return no2,"is Greater"
        else:
             return no3,"is Greater"
def main():
    print("Enter the number")
    try : 
        no1=int(input())
        no2=int(input())
        no3=int(input())
        ans=Maximun(no1,no2,no3)
        print(ans)
        
    except ValueError as vobj:
         print("Exception Occured invalid Charcater entered",vobj)    
if __name__=="__main__":
    main()