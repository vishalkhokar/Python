def sum(a,b):
    return a+b
def Difference(a,b):
    return a-b
def Product(a,b):
    return a*b
def Division(a,b):
    return a/b