def Evenodd(no1):
        if no1%2==0:
            return no1,"is a Even Number"
        else:
             return no1,"is a Odd Number" 
              

def main():
    print("Enter the Number")
    no1=int(input())
    ans=Evenodd(no1)
    print("",ans)
if __name__=="__main__":
    main()