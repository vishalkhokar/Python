import Marvellous
def main():
    try:

        print("Enter the First Number")
        no1=int(input())
        print("Enter the Second Number")
        no2=int(input())

        Addition=Marvellous.sum(no1,no2)
        print("Addition is ",Addition)
    
        subtract=Marvellous.Difference(no1,no2)
        print("Subtraction is ",subtract)

        Mult=Marvellous.Product(no1,no2)
        print("Multiplication is",Mult)

        divi=Marvellous.Division(no1,no2)
        print("Division is ",divi)

    except ZeroDivisionError as zobj:
        print("Exception Occured due division with 0",zobj)    
    
    except ValueError as vobj:
        print("Excepetion Occured Invalid data ",vobj)

    except Exception as eobj:
        print("Exception Occured",eobj)    

    
if __name__=="__main__":
    main()