def Fahrenteit(no1):
       f=(no1 * 9/5) +32
       return f 
def main():
    print("Enter the temperature")
    no1=float(input())
    ans=Fahrenteit(no1)
    print("Temperature in Fahrenheit",ans,"F")
if __name__=="__main__":
    main()