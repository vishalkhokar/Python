import multiprocessing
import threading
import time
def summation(no):
    starttime=time.time()
    sum=0
    for i in range(1,no):
        sum = sum+i
    print("Printing Sum from Normal Function",sum)    
    endtime=time.time()
    print(endtime - starttime  )   
    
def threadsummation(no):
    starttime=time.time()
    sum=0
    for i in range(1,no):
        sum = sum+i
    print("Printing Sum from Thread Function",sum)    
    endtime=time.time()
    print("Thread Function",endtime - starttime  )   
    
def processsummation(no):
    starttime=time.time()
    sum=0
    for i in range(1,no):
        sum = sum+i
    print("Printing Sum from process Function",sum)    
    endtime=time.time()
    print("process Function",endtime - starttime  )        
     
def main():
    try:
        print("Enter the Number")
        no=int(input())
        ans=summation(no)
        t1=threading.Thread(target=threadsummation,args=(no,))
        t1.start()
        t1.join()
        p1=multiprocessing.Process(target=processsummation,args=(no,))
        p1.start()
        p1.join()
        print("End Of Main thread")
    except ValueError as vobj:
        print("Invalid Data",vobj)    
if __name__=="__main__":
    main()