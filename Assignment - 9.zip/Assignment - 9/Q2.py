import multiprocessing
def squareList(data):
    for i in range(len(data)):
        data[i]=data[i]*data[i]
    print(data)
def main():
    try:
        print("enter the size")
        siz=int(input())
        data=[]
        print("Enter the element in an list")
        for i in range(siz):
            no=int(input())
            data.append(no)
        print(data)    
        
        P1=multiprocessing.Process(target=squareList,args=(data,))
        P1.start()
        P1.join()
    except ValueError as vobj:
        print("invalid element entered",vobj)           
if __name__=="__main__":
    main()   