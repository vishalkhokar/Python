import multiprocessing
def factorial(data):
    fact=1
    for i in range(data):
        fact=fact*data
        data=data-1
    return (fact)            
def main():
    try:
        print("Enter the Number")
        no=int(input())
        data=[]
        print("Enter the element in a List")
        for i in range(no):
            no1=int(input())
            data.append(no1)
        p=multiprocessing.Pool()
        res=p.map(factorial,data)
        p.close()
        p.join()
        print(res)
    except ValueError as vobj:
        print("Invalid Element entered",vobj)
if __name__=="__main__":
    main()                
        