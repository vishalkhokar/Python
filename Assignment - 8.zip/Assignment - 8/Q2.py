import threading
def EvenFactor(no):
    print("EvenFactor thread=",threading.get_ident())
    sum=0
    for i in range(no):
        if i%2==0:
            print("Even Number",i)
            sum=sum+i 
    print("Sum of EvenFactor",sum)  
def OddFactor(no):
    
    print("OddFactor thread=",threading.get_ident())
    sum=0
    for i in range(no):
        if i%2!=0:
            print("Odd Number",i)
            sum=sum+i 
    print("Sum of ODDFactor",sum)             
def main():
    print("thread of Main",threading.get_ident())
    t1=threading.Thread(target=EvenFactor,args=(20,))
    t2=threading.Thread(target=OddFactor,args=(20,))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    print("End of Main thread",threading.get_ident())
if __name__=="__main__":
    main()