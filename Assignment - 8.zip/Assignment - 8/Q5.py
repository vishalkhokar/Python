import threading
import time
def Display1(no):
    for i in range(1,no+1):
        print(i)
    
def reverseDisplay(no):
    for i in range(no,0,-1): 
        print(i)       
def main():   
   try: 
    print("Enter the Number")   
    no=int(input())
    T1=threading.Thread(target=Display1,args=(no,))   
    T2=threading.Thread(target=reverseDisplay,args=(no,))
    T1.start()
    T2.start()
    T1.join()  
    time.sleep(10) 
    print("t2 Started")
    
   
    T2.join()
    print("End Of Main thread")
   except ValueError as eobj:
       print("Invalid Input please entre a correct Number") 
if __name__=="__main__":
    main()