import threading
def CountSmall(datalist):
    cnt=0
    for i in range(len(datalist)):
        if (datalist[i])>="a" and  (datalist[i])<="z":
          cnt=cnt+1
          
    print("small case letter in a given string are",cnt)      
def CountCapital(datalist):
    cnt=0
    for i in range(len(datalist)):
        if (datalist[i])>="A" and  (datalist[i])<="Z":
          cnt=cnt+1
          
    print("CAPITAL case letter in a given string are",cnt)      
def CountDigit(datalist):
    cnt=0
    for i in range(len(datalist)):
        if (datalist[i])>="0" and  (datalist[i])<="9":
          cnt=cnt+1
          
    print("Number given string are",cnt)        
       
def main():
    print("Main thread",threading.get_ident())
    try : 
        print("Enter the String")
        data=input()
        t1=threading.Thread(target=CountSmall,args=(data,)) 
        t2=threading.Thread(target=CountCapital,args=(data,))
        t3=threading.Thread(target=CountDigit,args=(data,))   
        t1.start()
        t2.start()
        t3.start()
        t1.join()
        t2.join()
        t3.join()
        print("End of Main thread",threading.get_ident())    
    except ValueError as vobj:    
        print("Please enter a Valid Element",vobj)
if __name__=="__main__":
    main()