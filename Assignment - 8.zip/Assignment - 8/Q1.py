import threading
def EvenNumber(no):
    print("Thread of Even Number thread",threading.get_ident())
    for i in range(no):
        if i%2==0:
            print("Even Number",i)
def OddNumber(no):
    print("Thread of Odd Number thread",threading.get_ident())
    for i in range(no):
        if i%2!=0:
            print("ODD  Number",i)    
        
def main():
    print("Thread Of Main",threading.get_ident())
    print("Parallel execution")
    t1=threading.Thread(target=EvenNumber,args=(20,))
    t2=threading.Thread(target=OddNumber,args=(20,))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    print("ENd Of Main thread")
if __name__=="__main__":
    main()