import threading
def EvenList(datalist):
    print(type(datalist))
    print("Even List thread is ",threading.get_ident())
    sum=0
    for i in datalist:
        if i%2==0:
            sum=sum + i
    print("Even Sum=",sum) 
def OddList(datalist):
    print("Even List thread is ",threading.get_ident())
    sum=0
    for i in datalist:
        if i%2!=0:
            sum=sum + i
    print("Odd Sum=",sum)        
def main():
    print("Main thread",threading.get_ident())
    try : 
        print("Enter the Size of List")
        siz=int(input())
        data=[]
        print("Enter the Element in List")
        for i in range(siz):
            no=int(input())
            data.append(no)
        print("data",data)
        t1=threading.Thread(target=EvenList,args=(data,)) 
        t2=threading.Thread(target=OddList,args=(data,))   
        t1.start()
        t2.start()
        t1.join()
        t2.join()
        print("End of Main thread",threading.get_ident())    
    except ValueError as vobj:    
        print("Please enter a Valid Element",vobj)
if __name__=="__main__":
    main()