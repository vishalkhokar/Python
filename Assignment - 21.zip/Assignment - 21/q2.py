import psutil
class RunningExe:
    def __init__(self,exename):
        self.exename=exename
    def DisplayInfo(self):
        flag=False
        for proc in psutil.process_iter():
            info=proc.as_dict(attrs=['name','pid'])
            if info.get('name')==self.exename:
                print(info)
                flag=True
        if flag==False:
            print("No Such process is running currently")
def main():
    print("Enter the Name of Process")
    try: 
        processName=input()
        rexe=RunningExe(processName)
        rexe.DisplayInfo()
    except Exception as eobj:
        print("Exception Occured")    
if __name__=="__main__":
    main()