import psutil
def RunningProcess():
    for proc in psutil.process_iter():
       run=proc.as_dict(attrs=['pid','name'])
       print(run)
def main():
    RunningProcess()
if __name__=="__main__":
    main()