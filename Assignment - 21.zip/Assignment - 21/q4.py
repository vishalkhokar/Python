import psutil
import smtplib
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
class RunningExe:
    def __init__(self,exename):
        self.exename=exename
    def DisplayInfo(self):
        flag=False
        print("Enter the name of log file")
        filename=input()
        fobj=open(filename,"a")        
        for proc in psutil.process_iter():
            info=proc.as_dict(attrs=['name','pid'])
            print(info)
            fobj.write(str(info) + "\n")
        sender_email="vishalkhokar2710@gmail.com"
        receiver_email="vishalkhokar96@gmail.com"
        password="zaic thdw myti wxon"
        
        subject="Running Processes of System"
        body="Please find the attach file"
        
        
        msg=MIMEMultipart()
        msg['From']=sender_email
        msg['To']=receiver_email
        msg['Subject']=subject
        
        Logfile='./Log.txt'
        
        with open (filename,'rb') as attachment:
            part=MIMEBase('application','octet-stream')
            part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f"attachment; filename={Logfile}",
        )
        msg.attach(part)
        
        try:
            server=smtplib.SMTP('smtp.gmail.com',587)
            server.starttls()
            server.login(sender_email,password)
            server.sendmail(sender_email,receiver_email,msg.as_string())
            print("Email with attachment sent successfully")
        except Exception as e:
            print(f"error :{e}")
            
def main():
    print("Enter the Name of Process")
    try: 
        processName=input()
        rexe=RunningExe(processName)
        rexe.DisplayInfo()
    except Exception as eobj:
        print("Exception Occured")    
if __name__=="__main__":
    main()