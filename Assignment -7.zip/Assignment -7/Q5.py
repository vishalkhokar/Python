def chkPalindrome(data):  
      newstr=""  
      for i in range(-1,(-len(data)-1),-1) :    
          newstr=newstr + (data[i])
      if newstr==data:
        return "it is a Palindrome"
      else:
          return "It is not a Palindrome"        
def main():
        print("Enter the String")
        str1=(input())
        
        ans=chkPalindrome(str1)
        print(str1,"is a Palindrome")
if __name__=="__main__":
    main()