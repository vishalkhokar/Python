from functools import reduce
def producttwo(a,b):    
    return a*b 
def main():
    try: 
        data = []
        print("Enter the Size of list")
        no1 = int(input())

        for i in range(no1):
            no = int(input())
            data.append(no)
        
        x = reduce(producttwo, data)
        print(x)

    except ValueError as vobj:
        print("Invalid character entered instead of a number:", vobj)

if __name__ == "__main__":
    main()
