def CheckPrime(data):
    newPrime=[]
    i=0
    flag=0    
    for j in range(2,data//2):       
            if data%j==0:
                flag=1
                break

    if flag==0:
        newPrime.append(data)   
    return newPrime
def main():
    try: 
        data = []
        print("Enter the Size of list")
        no1 = int(input())

        for i in range(no1):
            no = int(input())
            data.append(no)
        
        x = list(filter(CheckPrime, data))
        print(x)

    except ValueError as vobj:
        print("Invalid character entered instead of a number:", vobj)

if __name__ == "__main__":
    main()
