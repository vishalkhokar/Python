def EvenList(data):  
        return data%2==0
def main():
        
        data=[]
        print("Enter the Size of list")
        no1=int(input())
        for i in range(no1):
            no=int(input())
            data.append(no)
        
        x=list(filter(EvenList,data))
        print(x)    
if __name__=="__main__":
    main()