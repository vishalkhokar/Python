sqaure=lambda no1:no1**2
cube=lambda no1:no1**3
def main():
    print("Enter the Number")
    no1=int(input())
    squa=sqaure(no1)
    print("Square of a Given number is ",squa)
    cub=cube(no1)
    print("Cube of a Given number is ",cub)
if __name__=="__main__":
    main()