class BookStore:
    NoofBooks = 0
    def __init__(self,bookname,author):
        self.bookname = bookname
        self.author = author
        BookStore.NoofBooks=BookStore.NoofBooks + 1
    def display(self):
        print(self.bookname,"by", self.author,",No of books",self.NoofBooks)
        
obj1=BookStore("C Programming","Dennis Ritchie")   
obj1.display()

obj2=BookStore("Python Programming","John Doe")
obj2.display()