class Arithematic:
    value=0
    def __init__(self,no):
        self.value = no
    
    def CheckPrime(self):
        for i  in range(2,self.value):
            if self.value%i==0:
                return False
        return True
    def checkPerfect(self):
        sum=0
        for i in range(1,self.value+1):
            sum=sum+i
    
        if sum==self.value:
            return True
        else:
            return False
    def checkFactor(self):
        factor=[]
        for i in range(1,self.value+1):
            if self.value%i==0:
                factor.append(i)
        return factor    
    def sumfactor(self):
        total=0
        for i in range(1,self.value+1):
            if self.value%i==0:
                total=total+i
        return total

Aobj1=Arithematic(6)
print("Is the number prime?", Aobj1.CheckPrime())
print("Is the number perfect?", Aobj1.checkPerfect())       
print("Factors of the number are:", Aobj1.checkFactor()) 
print("Sum of factors of the number is:", Aobj1.sumfactor())