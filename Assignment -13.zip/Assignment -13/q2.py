class BankAccount:
    ROI=10.5
    def __init__(self,Name,Amount):
        self.Name = Name
        self.Amount = Amount
    def desposit(self,DepositAmount):
          print("Account holder name:",self.Name) 
          print("Total balance before deposit is ",self.Amount)
          self.Amount += DepositAmount
          print("Total balance after deposit is ",self.Amount)
    def withdraw(self,withdrawAmount):
        if withdrawAmount > self.Amount:
            print("Insufficient balance")
        else:
            self.Amount -= withdrawAmount
            print("Total balance after withdrawal is ",self.Amount)   
    def display(self):
        print("Account holder name:",self.Name) 
        print("Account balance:",self.Amount)          
    def rateofinterest(self):
        print("Rate of interest is",self.ROI)
        totalinterest = (self.Amount * self.ROI) / 100
        print("Total interest on the current balance is", totalinterest)
Obj1=BankAccount("Vishal",500000)
Obj1.desposit(100000)
Obj1.withdraw(20)   
Obj1.display()
Obj1.rateofinterest()    


Obj2=BankAccount("Nishika",1000000)
Obj2.desposit(100000)
Obj2.withdraw(20)   
Obj2.display()
Obj2.rateofinterest()  