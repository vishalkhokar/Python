import MarvellousNum
def main():
    print("Enter the Size of List")
    no=int(input())
    data=[]
    print("Enter the Element in List")
    for i in range(no):
        num=int(input())
        data.append(num)

    SumofPrime=MarvellousNum.CheckPrime(data)
    print("Sum of PRIME number is ",SumofPrime)
if __name__=="__main__":
    main()        