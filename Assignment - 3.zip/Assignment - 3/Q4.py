def CountElement(data,findno):
    count=0
 #   print(data.count(findno))
    for i in range(len(data)):
        if data[i]==findno:
            count=count+1
        print(data.count(findno))
    return count               
def main():
    print("Enter the Size of List")
    while True:
        siz=int(input())
        if siz<1:
            print("Enter the Number greater then 0")
        else:
            break    
    data=[]
    print("Enter the Element in LIST")
    for i in range(siz):
        no=int(input())
        data.append(no)
    print("Enter the Number to be Searched in LIST")
    findno=int(input())    

    ans=CountElement(data,findno)    
    print('Number Count is ',ans)    
if __name__=="__main__":
    main()