def Sum(data):
   ans= sum ([data[i] for i in range(len(data))])    
   return ans

def main():
    print("Enter the Size of List")
    siz=int(input())
    data=[]
    for i in range(siz):
        no=int(input())
        data.append(no)
    summation=Sum(data)
    print("Summation of List element is ",summation)
if __name__=="__main__":
    main()    