def CheckPrime(data):
    add=0    
    print()
    i=0
    while(i<len(data)):   
        flag=0
        for j in range(2,data[i]):       
            if data[i]%j==0:
                flag=1
                break

        if flag==0:
            add=add+data[i]
        i=i+1
    return add