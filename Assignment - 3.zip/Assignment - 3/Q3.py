def Minimum(data):
    mini=data[0]
    for i in range(len(data)):
       if mini>data[i]:
          mini=data[i]
    return mini      
def main():
    print("Enter the Size of List")
    siz=int(input())
    data=[]
    print("Enter the Element in List")
    for i in range(siz):
      no=int(input())  
      data.append(no)
    ans=Minimum(data)
    print("Minimum Element from a List item is ",ans)

if __name__=="__main__":
   main()