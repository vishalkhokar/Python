def Sum(data):
    ans=0
    for i in range(len(data)):
        ans=data[i]+ans
    return ans    
    
def main():
    print("Enter the Size of List")
    siz=int(input())
    data=[]
    for i in range(siz):
        no=int(input())
        data.append(no)
    summation=Sum(data)
    print(summation)
if __name__=="__main__":
    main()    