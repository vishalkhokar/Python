def Maximun(data):
    max=data[0]
    for i in range(len(data)):
       if max<data[i]:
          max=data[i]
    return max      
def main():
    print("Enter the Size of List")
    siz=int(input())
    data=[]
    print("Enter the Element in List")
    for i in range(siz):
      no=int(input())  
      data.append(no)
    ans=Maximun(data)
    print("Maximum Element from a List item is ",ans)

if __name__=="__main__":
   main()