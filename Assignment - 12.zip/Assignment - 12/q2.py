class Cirlce:
    PI=3.14
    def __init__(self,radius,Area,Circumference):
       self.radius = 0
       self.Area = 0
       self.Circumference=0
    def Accept(self):
        print("Enter the Radiuis of Circle:")
        self.radius = float(input())
    def CaluclateArea(self):
       self.Area=Cirlce.PI*self.radius*self.radius
    def CalucalteCircumference(self):
      self.Circumference=2*Cirlce.PI*self.radius
      
    def Display(self):
        print("Radius of Circle:", self.radius)
        print("Area of Circle:", self.Area)
        print("Circumference of Circle:", self.Circumference)
cobj1=Cirlce(0,0,0)
cobj1.Accept()
cobj1.CaluclateArea()
cobj1.CalucalteCircumference()
cobj1.Display()