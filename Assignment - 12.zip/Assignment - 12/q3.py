class Arithematic:
    def __init__(self,value1,value2):
        self.value1=0
        self.value2=0
    def Accept(self):
        print("Enter the Value1 and Value2")
        self.value1=float(input())
        self.value2=float(input())
    def Addition(self):
        add=self.value1+self.value2
        return add
    def Subtraction(self):
        sub=self.value1-self.value2
        return sub
    def Multiplication(self):
        mul=self.value1*self.value2
        return mul    
    def Division(self):
        if self.value2 <1:
            print("Division with 0")
            return 0
        else:    
            divi=self.value1/self.value2
            return divi 
            
Aobj1=Arithematic(3,1)
Aobj1.Accept()
b=Aobj1.Addition()
print("Addition is ",b)
c=Aobj1.Subtraction()
print("Subtraction is ",c)
M=Aobj1.Multiplication()
print("Multiplication is ",M)
d=Aobj1.Division()
print("Division is ",d)