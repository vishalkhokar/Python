class demo:
    value=0
    def __init__(self,no1,no2):
        self.no1=no1
        self.no2=no2
    def fun(self):
        print(self.no1,self.no2)
    def gun(self):
        print(self.no1,self.no2)

obj1=demo(11,21)
obj2=demo(51,1101)
obj1.fun()
obj2.fun()
obj1.gun()
obj2.gun()