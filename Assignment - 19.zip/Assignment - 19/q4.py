import os
import shutil
class CopyDir:
    def __init__(self,Dirname):
        self.Dirname=Dirname
    def copyfile(self):
        print("Enter the BackUp Folder Name")
        backDir=input()
        os.mkdir(backDir) 
        path=os.path.abspath(backDir)
        shutil.copytree(self.Dirname,path,dirs_exist_ok=True)
def main():
    print("Enter the Directory Name")
    Dirname=input()
    ret=os.path.isdir(Dirname)
    if ret==False:
        print("No Such Directory found in System")
        exit(0)
    else:    
        Eobj=CopyDir(Dirname)
        Eobj.copyfile()
if __name__=="__main__":
    main()