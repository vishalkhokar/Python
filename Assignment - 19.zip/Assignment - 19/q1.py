import os
class Extension:
    def __init__(self,Dirname,ext):
        self.Dirname=Dirname
        self.ext=ext
    def Search(self):
        iCnt=0
        for FolderName,subfolder,Filename in os.walk(self.Dirname):
            for Fname in Filename:
                one=os.path.splitext(Fname)
                for i in one:
                    if i ==self.ext:
                        iCnt =iCnt + 1
                        print(Fname)
        print("Total File in Directory with ",self.ext, "extension are ",iCnt)      
def main():
    print("Enter the Directory Name")
    Dirname=input()
    ret=os.path.isdir(Dirname)
    print("Enter the Extension of File")
    ext=input()
    if ret==False:
        print("No Such Directory found in System")
        exit(0)
    else:    
        Eobj=Extension(Dirname,ext)
        Eobj.Search()
if __name__=="__main__":
    main()