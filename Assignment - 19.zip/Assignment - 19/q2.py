import os
class Extension:
    def __init__(self,Dirname,ext,ext2):
        self.Dirname=Dirname
        self.ext=ext
        self.ext2=ext2
    def Search(self):
        for FolderName,subfolder,Filename in os.walk(self.Dirname):
            for Fname in Filename:
                joiningpath=os.path.join(FolderName,Fname)
                base_name,one=os.path.splitext(joiningpath)
                new_file_path = base_name + "." + self.ext2
                os.rename(joiningpath,new_file_path)
        print("Renamed File Successfuuly ")        
def main():
    print("Enter the Directory Name")
    Dirname=input()
    ret=os.path.isdir(Dirname)
    print("Enter the Extension of File")
    ext=input()
    print("Enter the Second Extension")
    ext2=input()
    if ret==False:
        print("No Such Directory found in System")
        exit(0)
    else:    
        Eobj=Extension(Dirname,ext,ext2)
        Eobj.Search()
if __name__=="__main__":
    main()