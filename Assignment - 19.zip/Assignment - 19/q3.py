import os
import shutil
class CopyDir:
    def __init__(self,Dirname,Dirname2):
        self.Dirname=Dirname
        self.Dirname2=Dirname2
    def copyfile(self):
        shutil.copytree(self.Dirname,self.Dirname2,dirs_exist_ok=True)
def main():
    print("Enter the Directory Name")
    Dirname=input()
    ret1=os.path.isdir(Dirname)
    print("Enter the Name of Destination folder")
    Dirname2=input()
    ret2=os.path.isdir(Dirname2)
    
    if ret1 and ret2==False:
        print("No Such Directory found in System")
        exit(0)
    else:    
        Eobj=CopyDir(Dirname,Dirname2)
        Eobj.copyfile()
if __name__=="__main__":
    main()