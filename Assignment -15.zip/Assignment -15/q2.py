import os

def Openfile(fileName):
    ret=os.path.exists(fileName)
    if ret==True:
        
       fobj=open(fileName,"r") 
       data=fobj.read()
       
       print("Data in",fileName,"is",data)
    else:
        print("No Such file exists")

def main():
    fileName=input()
    Content=Openfile(fileName)
if __name__=="__main__":
    main()