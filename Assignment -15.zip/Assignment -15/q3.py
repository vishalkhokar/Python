def ContentCopy(filename,Copyfile):
    fopen=open(Copyfile,"r")
    data=fopen.read()
    
    fopen2=open(filename,"w")
    fopen2.write(data)
    
    fopen2=open(filename,"r")
    copied=fopen2.read()
    print(copied)
    
import os
def main():
    print("Enter the Name of File you want to create")
    Filename=input()
    
    ret=os.path.exists(Filename)
    while(True):
        if ret==True:
            print("file Already exits Please enter a different filename")
            print("Enter the Name of File you want to create")
            Filename=input()
            ret=os.path.exists(Filename)
        else:
            break     
           
    print("Enter the filename who content has to be copied")
    Copyfile=input()
    ret=os.path.exists(Copyfile)
    
    if ret==True:
        ContentCopy(Filename,Copyfile)
    else:
        print("No Such file")  
     
if __name__=="__main__":
    main()