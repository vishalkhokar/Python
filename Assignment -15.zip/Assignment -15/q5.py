import os
def CountFreq(fileName,sear):
   fopen=open(fileName,"r")
   data=fopen.read()
   totalCnt=0
   data=data.lower()
   exp2=data.split()
   for i in exp2:
       if i==sear:
           totalCnt=totalCnt+1
   return totalCnt      
def main():
    print("Enter name of File")
    fileName=input()
    ret=os.path.exists(fileName)
    print(ret)
    if ret==True:
        print("Enter the String to be searched")
        sear=input()
        sear=sear.lower()
        Content=CountFreq(fileName,sear)
        print(Content)
    else:
        print("No Such File exist in Our System")
if __name__=="__main__":
    main()