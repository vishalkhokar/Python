import os
def checkFile(fileName):
    ret=os.path.exists(fileName)
    if ret==True:
        return "Yes file exists"
    else:
        return "No such file"
def main():
    print("Enter the File Name")
    fileName=input()
    ans=checkFile(fileName)
    print(ans)
if __name__=="__main__":
    main()