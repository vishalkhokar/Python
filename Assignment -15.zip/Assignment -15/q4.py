def CompareContent(Filename1,Filename2):
    fopen1=open(Filename1,"r")
    data1=fopen1.read()
    
    fopen2=open(Filename2,"r")
    data2=fopen2.read()
    
    if data1==data2:
        print("Content is same")
        print("data from file 1 ",data1)
        print("data from file 2 ",data2)
    else:
        print("Content is not same")
        print("data from file 1 ",data1)
        print("data from file 2 ",data2)
    
import os
def main():
    print("Enter the Name of first  File")
    try:
        Filename1=input()

        print("Enter the Name of Second  File")
        Filename2=input()
    
        ret1=os.path.exists(Filename1)
        ret2=os.path.exists(Filename2)
    except ValueError as e:
        print("Please enter Correct input",e)
     
        if ret1 and ret2:
            CompareContent(Filename1,Filename2)
        else:
            print("No Such file")   
     
if __name__=="__main__":
    main()