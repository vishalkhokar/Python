def Looping(no):
    i=1
    while(i<=no):
        print(i,end=" ")
        i=i+1
def main():
    try:
        print("Enter the Number")
        no1=int(input())
        Looping(no1)
    except ValueError as vobj:
        print("Invalid Charcter entered instead of Number",vobj)    
if __name__=="__main__":
    main()