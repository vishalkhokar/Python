def CheckPrime(data):
    flag=0
    for j in range(2,data//2):       
            if data%j==0:
                flag=1
                break

    if flag==0:
        return data,"is a Prime Number"
    else:
         return data,"is not a Prime Number" 
def main():
    try:
        print("Enter the Number")
        no1=int(input())
        ans=CheckPrime(no1)
        print(ans)
    except ValueError as vobj:
        print("Invalid Charcter entered instead of Number",vobj)    
if __name__=="__main__":
    main()