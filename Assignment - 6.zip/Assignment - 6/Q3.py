def Table(no):
    i=1
    while(i<=10):
            print(no,"*",i ,"=",no*i)
            i=i+1       
def main():
    try:
        print("Enter the Number")
        no1=int(input())
        Table(no1)
    except ValueError as vobj:
        print("Invalid Charcter entered instead of Number",vobj)    
if __name__=="__main__":
    main()