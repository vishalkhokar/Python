def Factor(no):
    ifact=1
    for i in range(1,no):
        ifact=no*ifact
        no=no-1
    return ifact    
def main():
    try:
        print("Enter the Number")
        no1=int(input())
        ans=Factor(no1)
        print(ans)
    except ValueError as vobj:
        print("Invalid Charcter entered instead of Number",vobj)    
if __name__=="__main__":
    main()