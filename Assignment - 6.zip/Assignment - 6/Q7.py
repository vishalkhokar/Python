def Max(no1,no2,no3,no4,no5):
     if no1>no2 and no1>no3 and no1>no4 and no1>no5:
        return "Maximun  number is ",no1
     elif no2>no3 and no2>no4 and no2>no5:
         return "Maximun number is ",no2
     elif no3>no4 and no3>no5:
         return "Maximun number is ",no3
     elif no4>no5:
         return "Maximun number is ",no4
     else : 
         return "Maximun number is ",no5
def main():
    print("Enter the First Number")
    no1=float(input())
    print("Enter the Second Number")
    no2=float(input())
    print("Enter the Third Number")
    no3=float(input())
    print("Enter the fourth Number")
    no4=float(input())
    print("Enter the five Number")
    no5=float(input())
    
    ans=Max(no1,no2,no3,no4,no5)
    print("Area",ans)
if __name__=="__main__":
    main()