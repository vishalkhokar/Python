def EvenSum(no):
    i=1
    sum=0
    while(i<=no):
        if i%2==0:
            sum=sum+i
        i=i+1
    return sum    
def main():
    try:
        print("Enter the Number")
        no1=int(input())
        finalans=EvenSum(no1)
        print(finalans)
    except ValueError as vobj:
        print("Invalid Charcter entered instead of Number",vobj)    
if __name__=="__main__":
    main()