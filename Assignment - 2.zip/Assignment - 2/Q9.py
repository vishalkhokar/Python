def CountNum(no):
      copyno=no
      cnt=0
      while(copyno!=0):
          cnt=cnt+1
          copyno=copyno//10
  
      return cnt
def main():
    print("Enter the Number")
    no=int(input())
    if no<1:
        print("Number should be greater then 0")
        exit(0)
    ans=CountNum(no)
    print(ans)   
if __name__=="__main__":
    main()    