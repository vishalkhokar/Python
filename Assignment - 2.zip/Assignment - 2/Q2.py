def printPattern(no):
    for i in range(no):
        print("*"*no)
def main():
    print("Enter the Number")
    no=int(input())
    if no<1:
        print("Invalid Number")
        exit()

    printPattern(no)
if __name__=="__main__":
    main()        