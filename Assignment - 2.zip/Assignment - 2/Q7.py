def Pattern(no):
    for i in range(no):
        for j in range(1,no+1):
            print(j ,end=" ")
        print()
def main():
    print("Enter the Number")
    no=int(input())
    while no<1: 
        print("Please enter number greater then 0")
        print("Enter the Number")
        no=int(input())
    Pattern(no)
if __name__=="__main__":
    main()
