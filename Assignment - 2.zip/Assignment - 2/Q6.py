def Pattern(no):
    for i in range(no,0,-1):
        print("* "*i)
def main():
    print("Enter the Number")
    no=int(input())
    while no<1: 
        print("Please enter number greater then 0")
        print("Enter the Number")
        no=int(input())
    Pattern(no)
if __name__=="__main__":
    main()
