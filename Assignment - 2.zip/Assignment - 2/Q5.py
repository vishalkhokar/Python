def Chkprime(no):
    for i in range(2,no//2):
        if no%i==0:
            return -1
    else:
        return 1    
def main():
    print("Enter the Number")
    no=int(input())
    if no<1:
        print("Number should be greater then 0")
        exit(0)
    ans=Chkprime(no)
    if ans==1:
        print("It is prime Number",no)
    else:
        print("It is not Prime Number",no)    
if __name__=="__main__":
    main()    