import arithematic
def main():
    print("Enter the First Number")
    first=int(input())
    print("Enter the Second Number")
    second=int(input())

    add=arithematic.Add(first,second)
    print("Addition of two number is",add)
    sub=arithematic.Sub(first,second)
    print("Subtration of two number is",sub)
    mul=arithematic.mult(first,second)
    print("Multiplication of two number is",mul)
    if second<1:
        print("Please enter Number greater then 0")
    else:
        div=arithematic.divi(first,second)
        print("division of two number is",div)
if __name__=="__main__":
    main()