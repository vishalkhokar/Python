def Addition(no):
      copyno=no
      sum=0
      while(copyno!=0):
          sum=copyno%10+sum
          copyno=copyno//10
  
      return sum
def main():
    print("Enter the Number")
    no=int(input())
    if no<1:
        print("Number should be greater then 0")
        exit(0)
    ans=Addition(no)
    print(ans)   
if __name__=="__main__":
    main()    