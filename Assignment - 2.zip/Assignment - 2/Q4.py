def Addition(no):
    sum=0
    for i in range(1,no):
        if no%i==0:
            sum=sum+i
    return sum;        
def main():
    no=int(input())
    ans=Addition(no)
    print(ans)
if __name__=="__main__":
    main()