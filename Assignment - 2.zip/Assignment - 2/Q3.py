def factorail(no):
    fact=1
    for i in range(1,no+1):
        fact=i*fact
    return fact    
def main():
    print("Enter the Number")
    no=int(input())
    ans=factorail(no)
    print(ans)
if __name__=="__main__":
    main()