import datetime
import time
import schedule
class AajkiDate:
    def DisplayLunch(self):
        print(datetime.datetime.now(),"Its is Lunch time ")
    def PackUp(self):
        print(datetime.datetime.now(),"It is WrapUp Time")  
def main():
    aobj=AajkiDate()
    schedule.every(1).hour.at("01:00").do(aobj.DisplayLunch)
    schedule.every(1).hours.at("01:56").do(aobj.PackUp)  
    while(True):
            schedule.run_pending()
            time.sleep(1)
if __name__=="__main__":
    main()