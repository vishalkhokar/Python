import time
import schedule
class AajkiDate:
    def DisplayDateTime(self):
        print("Do Coding")
def main():
    aobj=AajkiDate()
    schedule.every(1).minute.do(aobj.DisplayDateTime)
    while(True):
        schedule.run_pending()
        time.sleep(1)
if __name__=="__main__":
    main()
