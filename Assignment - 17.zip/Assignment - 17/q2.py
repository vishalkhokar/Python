import datetime
import time
import schedule
class AajkiDate:
    def DisplayDateTime(self):
        print("Current date is ",datetime.datetime.now())
        
    def calling(self):
        schedule.every(1).minute.do(self.DisplayDateTime)    
def main():
    aobj=AajkiDate()
    aobj.DisplayDateTime()
    aobj.calling()
    while(True):
        schedule.run_pending()
        time.sleep(1)
if __name__=="__main__":
    main()
