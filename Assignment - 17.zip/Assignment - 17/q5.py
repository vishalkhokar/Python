import time
import schedule
class Every5:
    def __init__(self,filename):
        self.filename=filename
    def writing(self):
       fopen=open(self.filename,"a")
       print("Enter the Data in File")
       data=input()
       data=fopen.write(data + "\n") 
        
def main():
    print("Enter the File Name")
    filename=input()
    e5=Every5(filename)
    schedule.every(5).minutes.do(e5.writing)
    e5.writing()
    while(True):
         schedule.run_pending()
         time.sleep(1)
if __name__=="__main__":
    main()