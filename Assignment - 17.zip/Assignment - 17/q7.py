import time
import datetime
import os
import schedule
class Every5:
    def __init__(self,filename,backUp):
        self.filename=filename
        self.backUp=backUp
    def writing(self):
       fopen=open(self.filename,"r")
       data=fopen.read()
       fopen2=open(self.backUp,"a")
       logtime=datetime.datetime.now()
       data2=fopen2.write(str(logtime) +"\n")
       data2=fopen2.write(data)
        
def main():
    print("Enter the File Name which need a backUp")
    filename=input()
    print("Enter the Name of BackUp File")
    backUp=input()
    ret=os.path.exists
    if ret==True:
        e5=Every5(filename,backUp)
        schedule.every(1).minutes.do(e5.writing)
        e5.writing()
    else:
        print("NO Such File")
        exit()
    while(True):
         schedule.run_pending()
         time.sleep(1)
if __name__=="__main__":
    main()