import time
import datetime
import schedule
class CheckingEmail:
    def writing(self):
       print(datetime.datetime.now(),"Checking Email")
       
def main():
    eobj=CheckingEmail()
    schedule.every(10).seconds.do(eobj.writing)
    while(True):
         schedule.run_pending()
         time.sleep(1)
if __name__=="__main__":
    main()