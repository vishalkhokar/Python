import datetime
import time
import schedule
class AajkiDate:
    def DisplayDateTime(self):
        print("Namsakar")
def main():
    aobj=AajkiDate()
    schedule.every().hour.at("09:00").do(aobj.DisplayDateTime)
    print(datetime.datetime.now())
    while(True):
        a=datetime.datetime.now()
        if a.hour==1:
            schedule.run_pending()
            time.sleep(1)
if __name__=="__main__":
    main()