import time
import schedule
import datetime
class PrintGanesh:
    def ganesh(self):
        print("Jai Ganesh")
    def Caller(self):    
        schedule.every(2).seconds.do(self.ganesh)
def main():
    print("Current time is ",datetime.datetime.now())
    Gobje=PrintGanesh()
    Gobje.Caller() 
    while(True):
        schedule.run_pending()
        time.sleep(1)
if __name__=="__main__":
    main()