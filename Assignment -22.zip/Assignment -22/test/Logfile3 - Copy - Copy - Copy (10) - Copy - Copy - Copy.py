import sys
import time
def CreateLog():
    timestamp=time.ctime()
    
    filename ="MarvellousLog%s.log" %(timestamp)
    filename=filename.replace(" ","_")
    filename=filename.replace(":","_")

    fobj=open(filename,"w")
    border="-"*54
    fobj.write(border+"\n")
    fobj.write("\n\n\n\n\n\n")
    fobj.write(border+"\n")
    
    fobj.write("this is a log file of Marvellous automation script"+timestamp+"\n")
    fobj.write(border+"\n")
 

def main():
    CreateLog()           
if __name__=="__main__":
    main()