
import sys
import os 
import hashlib
import time
import schedule
import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
class DuplicateFiles:
    def __init__(self,Dirname,logfile):
        self.Dirname=Dirname
        self.logfile=logfile
    def CheckSum(self,fname):
        fobj=open(fname,"rb")
        hobj=hashlib.md5()
        
        buffer=fobj.read(1024) 
        while(len(buffer)>0):
            hobj.update(buffer)
            buffer=fobj.read(1024)
        fobj.close()
        return hobj.hexdigest()   
                 
    def DirectoryWatecher(self):
        Duplicatelist=[]
        totalCount=0
        fobj=open(self.logfile,"a")
        fobj.write("Duplicate File" + "\n")
        fobj.write(str(datetime.datetime.now()) + "\n")
        for folderName,Subfolder,FileName in os.walk(self.Dirname):
            for fname  in FileName:
               fname=os.path.join(folderName,fname,)
               ans = DuplicateFiles.CheckSum(self,fname)
               if ans not in Duplicatelist:
                    Duplicatelist.append(ans)
               else:
                   fobj.write(fname + "\n")  
                   os.remove(fname) 
                   totalCount=totalCount + 1
        fobj.write("Total duplicated File  deleted")
        fobj.write(str(totalCount) + "\n")   
        
    def SendEmail(self):    
        sender_email="vishalkhokar2710@gmail.com"
        receiver_email="vishalkhokar96@gmail.com"
        password="zaic thdw myti wxon"
        
        subject="Log of Deleted Files"
        body="Please find the attach file"    
        msg=MIMEMultipart()
        msg['From']=sender_email
        msg['To']=receiver_email
        msg['Subject']=subject
        
        Logfile='./log.txt'
        
        with open (self.logfile,'rb') as attachment:
            part=MIMEBase('application','octet-stream')
            part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f"attachment; filename={Logfile}",
        )
        msg.attach(part)
        
        try:
            server=smtplib.SMTP('smtp.gmail.com',587)
            server.starttls()
            server.login(sender_email,password)
            server.sendmail(sender_email,receiver_email,msg.as_string())
            print("Email with attachment sent successfully")
        except Exception as e:
            print(f"error :{e}")    
def main():
    print("Enter the File Name")
    logfile=input()
    ans=DuplicateFiles(sys.argv[1],logfile)
    schedule.every(1).minutes.do(ans.DirectoryWatecher)
    schedule.every(1).minutes.do(ans.SendEmail)
    while(True):
        schedule.run_pending()
        time.sleep(1)
        
if __name__=="__main__":
    main()