import os
import hashlib
class CheckSum:
    def __init__(self,filename):
        self.filename=filename
    def Csum(self):
        fobj=open(self.filename,'rb')
        hobj=hashlib.md5()

        buffer=fobj.read(10)
        while(len(buffer)>0):
            hobj.update(buffer)
            buffer=fobj.read(10)        
        fobj.close()    
        return hobj.hexdigest()    
def main():
    print("Enter the Name of File")
    fileName=input()
    if os.path.exists(fileName):
        Cvalue=CheckSum(fileName)
        ans=Cvalue.Csum()
        print("Check Sum value =",ans)
    else:
        print("No Such file ")
if __name__=="__main__":
    main()    