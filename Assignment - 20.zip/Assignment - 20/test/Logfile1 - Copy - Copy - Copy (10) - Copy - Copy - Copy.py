vishal
import sys
import time
def main():
    timestamp=time.ctime()
    print(timestamp)
    fobj=open("MarvellousLog.log","w")
    border="-"*54
    fobj.write(border+"\n")
    fobj.write("\n\n\n\n\n\n")
    fobj.write(border+"\n")
    
    fobj.write("this is a log file of Marvellous automation script"+timestamp)
    fobj.write(border+"\n")
    
    
if __name__=="__main__":
    main()