import os 
import hashlib
class DuplicateFiles:
    def __init__(self,Dirname):
        self.Dirname=Dirname
    def CheckSum(self,fname):
        fobj=open(fname,"rb")
        hobj=hashlib.md5()
        
        buffer=fobj.read(1024) 
        while(len(buffer)>0):
            hobj.update(buffer)
            buffer=fobj.read(1024)
        fobj.close()
        return hobj.hexdigest()   
                 
    def DirectoryWatecher(self):
        Duplicatelist=[]
        print("Enter the File Name")
        filename=input()
        fobj=open(filename,"a")
        
        for folderName,Subfolder,FileName in os.walk(self.Dirname):
            for fname  in FileName:
               fname=os.path.join(folderName,fname,)
               ans = DuplicateFiles.CheckSum(self,fname)
               if ans not in Duplicatelist:
                    Duplicatelist.append(ans)
               else:
                   fobj.write(fname + "\n")  
def main():
    print("Enter the Name of Directory ")
    DirectoryName=input()
    os.path.abspath(DirectoryName)
    
    flag=os.path.isdir(DirectoryName)
    if flag==False:
        print("Path is correct but it not Directory")
        exit()
    else:
        cobj=DuplicateFiles(DirectoryName)
        cobj.DirectoryWatecher()
if __name__=="__main__":
    main()