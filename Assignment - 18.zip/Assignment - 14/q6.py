class Calculator:
    def __init__(self,no1,no2):
        self.no1=no1
        self.no2=no2
    def add(self):
        sum=self.no1 + self.no2 
        return sum
    def subtract(self):
        sub=self.no1 - self.no2
        return sub
    def mult(self):
        mult=self.no1* self.no2
        return mult
    def div(self):
        try:
            divi=self.no1/self.no2
            return divi
        except ZeroDivisionError as zobj:
            print("division with 0")
Cobj=Calculator(10,20)
print("Addition is ",Cobj.add())
print("Subtraction is ",Cobj.subtract())
print("Multiplication is ",Cobj.mult())
ans=Cobj.div()
if ans==None:
    pass
else:
    print("Division is ",ans)
