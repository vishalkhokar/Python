class Student:
    SchoolName="Indira"
    def __init__(self,Name,rollno):
        self.Name=Name
        self.rollno=rollno
    def display(self):
        print("School Name",Student.SchoolName, "Student Name",self.Name,",Student rollno",self.rollno,)
eobj=Student("Rohit",44)
eobj.display()