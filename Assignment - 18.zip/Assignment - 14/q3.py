class Employee:
    __price=99
    
    def display(self):
        print("Price is ",Employee.__price)
eobj=Employee()
eobj.display()