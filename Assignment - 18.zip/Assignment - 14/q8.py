class Vehicle:
    def start(self):
        print("Top speed is 155")
class Car(Vehicle):
    def start(self):
        print("Top speed is 180")
        print("Mileage is 34kmph")
        print("Fuel capacity 44Liters")
     
pobj=Car()
pobj.start()
