class product:
    def __init__(self,name,price):
        self.name=name
        self.price=price
        
    def __eq__(self,other): 
       if self.price==other.price:
            print("One")
       else:
            print("no")
     
pobj1=product("x2yz",55)
pobj2=product("xyz",55)
pobj1.__eq__(pobj2)
