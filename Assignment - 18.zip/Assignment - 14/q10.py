class product:
    def __init__(self,salary,dep,name):
        self.__salary=salary
        self._dep=dep
        self.name=name
    def display(self):
        print(self._dep,self.__salary)  
     
pobj1=product(999,"hr","bhagshree")
pobj1.display()

print(pobj1._dep)
print(pobj1.name)

pobj2=product(8888,"er","Nikhil")
pobj2.display()

print(pobj2._dep)
print(pobj2.name)



