class Rectangle:
    def __init__(self,length,width):
        self.length=length
        self.width=width
    def Perimeter(self):
        p=(self.length + self.width)*2    
        return p
    def Area(self):
        a=self.length*self.width
        return a
Robj1=Rectangle(50,30)
Perimeter=Robj1.Perimeter()
print("Perimeter ",Perimeter)
A=Robj1.Area()
print("Area ",A)

Robj2=Rectangle(10,20)
Perimeter=Robj2.Perimeter()
print("Perimter",Perimeter)
A=Robj2.Area()
print("Area",A)
    