class Person:
    def __init__(self,Name,age):
        self.Name=Name
        self.age=age
    def display1(self):
        return self.Name,self.age
class Teacher(Person):
    
     def display(self):
        super().display1()
        self.subject="History"
        self.salary=99999
   
        print(self.Name,self.age,self.subject,self.salary)
pobj=Teacher("HHH",29)
pobj.display()
