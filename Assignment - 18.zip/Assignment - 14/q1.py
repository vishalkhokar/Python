class Employee:
    def __init__(self,Name,ID,Salary):
        self.Name=Name
        self.ID=ID
        self.Salary=Salary
    def display(self):
        print("Name",self.Name,",ID",self.ID,",Salary",self.Salary)
eobj=Employee("Rohit",44,888)
eobj.display()