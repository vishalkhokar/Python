from functools import reduce
def CheckPrime(data):
    flag=0
    for j in range(2,data//2):       
            if data%j==0:
                flag=1
                break

    if flag==0:
        print(data)
        return data
Add=lambda data:data*2
sum2=lambda a,b:max(a,b)    
print("Enter the Size of List")
siz=int(input())
data=[]
print("Enter the element in List")

for i in range(siz):
    no=int(input())
    data.append(no)

filteredData=list(filter(CheckPrime,data))    
print("Filter Data",filteredData)


mappedData=list(map(Add,filteredData))
print("Mapped Data",mappedData)

red=reduce(sum2,mappedData)
print("reduced Data",red)