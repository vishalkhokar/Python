mult=lambda no1,no2:no1*no2
def main():
    print("Enter the first Number")
    no1=int(input())
    print("Enter the Second Number")
    no2=int(input())
    ans=mult(no1,no2)
    print(ans)  
if __name__=="__main__":
    main()