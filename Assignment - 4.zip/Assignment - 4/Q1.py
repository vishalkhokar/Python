po=lambda no1,power:(no1**power)

no1=int(input("Enter the Number"))
tothePower=int(input("Enter the Power"))
ans=po(no1,tothePower)
print(ans)