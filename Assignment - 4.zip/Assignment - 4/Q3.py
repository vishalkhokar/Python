from functools import reduce
def greaterless(no):
    print("xxxxxxx",no)
    if no>=70 and no<=90:
        return no
def increament(no):
    return no + 10

def multi(a,b):
    return a*b    

print("Enter the size of LIST")
siz=int(input())    
data=[]
print("Enter the number in a  LIST")
for i in range(siz):
    no=int(input())
    data.append(no)

filterData=list(filter(greaterless,data))

print('Filtered Data',filterData)

MappedData=list(map(increament,filterData))
print("Mapped Data=",MappedData)

reducedData=reduce(multi,MappedData)
print(reducedData)