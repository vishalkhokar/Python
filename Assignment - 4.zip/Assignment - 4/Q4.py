from functools import reduce
Even= lambda no:no%2==0
Add = lambda no:no*no 
sum2=lambda a,b:a+b
print("Enter the Size of List")
siz=int(input())
data=[]
print("Enter the element in List")

for i in range(siz):
    no=int(input())
    data.append(no)

filteredData=list(filter(Even,data))    
print("Filter Data",filteredData)

mappedData=list(map(Add,filteredData))
print("Mapped Data",mappedData)

red=reduce(sum2,mappedData)
print("reduced Data",red)