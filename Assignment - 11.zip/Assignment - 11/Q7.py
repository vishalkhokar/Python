cnt=1
def Pattern(no):
    global cnt
    if cnt<=no:
       print("* "*cnt)
#       for i in range(cnt):
#           print("*",end="")
#       print()    
       cnt=cnt+1
       Pattern(no)    
def main():
    print("Enter the Number")
    try:
        no=int(input())
        ans=Pattern(no)
    except ValueError as vobj:
        print("Invalid Element  entered")    
if __name__=="__main__":
    main()