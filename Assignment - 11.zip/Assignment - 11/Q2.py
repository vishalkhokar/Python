fact=1
def RecFact(no):
    global fact
    if no>=1:
        fact=fact*no
        no=no-1
        RecFact(no)
    return fact     
def main():
    print("Enter the Number")
    try:
        no=int(input())
        ans=RecFact(no)
        print("Factorial of a Number",ans)
    except ValueError as vobj:
        print("Invalid Element  entered")    
if __name__=="__main__":
    main()