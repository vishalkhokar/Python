count=0
def CountZero(no):
    global count
    if no!=0:
       rem=no%10
       if rem==0:
        count=count+1 
       no=no//10
       CountZero(no) 
    return count     
def main():
    print("Enter the Number")
    try:
        no=int(input())
        ans=CountZero(no)
        print("Number of Zero",ans)
    except ValueError as vobj:
        print("Invalid Element  entered")    
if __name__=="__main__":
    main()