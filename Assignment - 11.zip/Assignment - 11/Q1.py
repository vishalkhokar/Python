i=1
def RecN(no):
    global i
    if i<=no:
        print(i,end=" ")
        i=i+1
        RecN(no)
    return "a"     
def main():
    print("Enter the Number")
    try:
        no=int(input())
        ans=RecN(no)
    except ValueError as vobj:
        print("Invalid Element  entered")    
if __name__=="__main__":
    main()