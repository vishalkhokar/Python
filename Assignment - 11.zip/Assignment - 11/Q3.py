sum=0
def SumofDigit(no):
    global sum
    if no!=0:
       rem=no%10
       sum=sum+rem
       no=no//10
       SumofDigit(no) 
    return sum     
def main():
    print("Enter the Number")
    try:
        no=int(input())
        ans=SumofDigit(no)
        print("Sum of a Number",ans)
    except ValueError as vobj:
        print("Invalid Element  entered")    
if __name__=="__main__":
    main()