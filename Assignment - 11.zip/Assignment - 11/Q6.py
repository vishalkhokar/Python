sum=0
def Natural(no):
    global sum
    if no!=0:
       sum=sum+no
       no=no-1
       Natural(no) 
    return sum     
def main():
    print("Enter the Number")
    try:
        no=int(input())
        ans=Natural(no)
        print("Sum of a Number",ans)
    except ValueError as vobj:
        print("Invalid Element  entered")    
if __name__=="__main__":
    main()