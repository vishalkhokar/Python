product=1
def toPower(no,pow):
    global product
    if pow>=1:
        product=product*no
        pow=pow-1
        toPower(no,pow) 
    return product     
def main():
    print("Enter the Number")
    try:
        no=int(input())
        pow=int(input())
        ans=toPower(no,pow)
        print("Sum of a Number",ans)
    except ValueError as vobj:
        print("Invalid Element  entered")    
if __name__=="__main__":
    main()