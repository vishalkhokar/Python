def Number(no1):

    if no1 >0:
        print("Positive Number")
 
    elif no1 < 0:
        print("negative Number")
    else :
        print("Zero")    
def main():
    print("Enter the First Number")
    no1=int(input())

    Number(no1)
    
if __name__=="__main__":
    main()