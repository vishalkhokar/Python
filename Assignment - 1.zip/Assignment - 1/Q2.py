def CheckNumber(number):
    if number % 2==0:
        print("Even number")
    else:
        print("Odd Number")    

def  main():
    print("Enter the Number")
    no=int(input())
    CheckNumber(no)

if __name__=="__main__":
    main()