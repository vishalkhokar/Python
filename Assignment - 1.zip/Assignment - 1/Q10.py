def Countx(str1):
       cnt=0
       for i in str1:
            cnt=cnt+1
  
       return cnt


def main():
    print("Enter the String")
    str1=input()

    cnt= Countx(str1)
    print(cnt)

if __name__=="__main__":
    main()