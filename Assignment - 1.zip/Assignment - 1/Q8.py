def Display(no):
        print("* "*no)

def main():
    print("Enter the Number")
    no=int(input())
    Display(no)

if __name__=="__main__":
    main()