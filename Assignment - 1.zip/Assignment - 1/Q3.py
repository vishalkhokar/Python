def Add(no1,no2):
    return no1+no2
def main():
    print("Enter the First Number")
    no1=float(input())

    print("Enter the Second Number")
    no2=float(input())

    ans=Add(no1,no2)
    print(ans)
if __name__=="__main__":
    main()