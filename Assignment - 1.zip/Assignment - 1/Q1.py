def fun():
    print("Hello from fun")

def main():
    fun()

if __name__=="__main__":
    main()