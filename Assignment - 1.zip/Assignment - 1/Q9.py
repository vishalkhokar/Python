def Display(no):
        for i in range(1,no*2,2):
             print("",i+1,end=" ")

def main():
    print("Enter the Number")
    no=int(input())
    Display(no)

if __name__=="__main__":
    main()