def Div(no1):
    if no1 %5==0:
        return True
    else:
        return False


def main():
    print("Enter the First Number")
    no1=int(input())

    ans=Div(no1)
    print(ans)
if __name__=="__main__":
    main()