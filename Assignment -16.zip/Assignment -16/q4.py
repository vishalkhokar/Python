class readdisplay:
    def __init__(self,filename):
        self.filename=filename
    def read(self):
        fopen=open(self.filename,"w")
        print("Enter the Number")
        i=1
        while(i<=10):
            data=input()
            data=fopen.write(data)
            i=i+1
            
        fopen=open(self.filename,"r")     
        data2=fopen.read()
        print("data in File is \n",data2)

def main():
    print("Enter the Filename which has to be write")
    filename=input()
    robj=readdisplay(filename)
    robj.read()
if __name__=="__main__":
    main()