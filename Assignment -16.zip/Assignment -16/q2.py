class readdisplay:
    def __init__(self,filename):
        self.filename=filename
    def read(self):
        try:
            fopen=open(self.filename,"r")
            data=fopen.read()
            print("data in File is \n",data)
        except FileNotFoundError as f:
            print("No Such file found") 
def main():
    print("Enter the Filename which has to be read")
    filename=input()
    robj=readdisplay(filename)
    robj.read()
if __name__=="__main__":
    main()