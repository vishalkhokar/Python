class Blankline:
    def __init__(self,filename):
        self.filename=filename
               
def main():
    print("Enter the Name of file")
    filename=input()
    fopen=open(filename,"w")
    print("Enter the content in the file ")
    i=1
    while(i<5):
        data1=input()
        data2=fopen.write(data1 +"\n")
        i=i+1
          
    fopen=open(filename,"r")
    data3=fopen.readlines()
    icnt=0
    print("Please enter the name of Second")
    fielname2=input()
    
    for i in data3:
        if i=="\n":
            fopen=open(fielname2,"a")
            data4=fopen.write(i.strip())
        else:
            fopen=open(fielname2,"a")
            data4=fopen.write(i)
    
    fopen=open(fielname2,"r")
    data3=fopen.readlines()
if __name__=="__main__":
    main()