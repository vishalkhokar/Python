class CountChar:
    def __init__(self,filename):
        self.filename=filename
        self.smallcase=0
        self.Capitalcase=0
        self.Space=0
        self.enter=0
        self.no=0
    def Count(self):
        try:
            fopen=open(self.filename,"r")
            data=fopen.read()
            for i in data:
                if i>='a' and i<='z':
                    self.smallcase=self.smallcase+1
                elif i>='A' and i<='Z':
                    self.Capitalcase=self.Capitalcase+1
                elif i==" ":
                    self.Space=self.Space+1
                elif i=="\n":
                    self.enter=self.enter+1
                elif int(i)>=0 and int(i)<=9:
                    self.no=self.no+1          
        except FileNotFoundError as f:
            print("No Such file found")
            
    def display(self):
            print('Small Case char are',self.smallcase)
            print("Capital case char are",self.Capitalcase)
            print("Total Spaces are",self.Space)
            print("Total Number ",self.no)            
def main():
    print("Enter the Filename which has to be read")
    filename=input()
    robj=CountChar(filename)
    robj.Count()
    robj.display()
if __name__=="__main__":
    main()