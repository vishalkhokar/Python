class stud:
    def __init__(self,filename):
        self.filename=filename
        self.fopen=None
    def Student(self):
        fopen=open(self.filename,"w")
        print("Enter the Name of Student in file")
        data=input()
        fwrite=fopen.write(data)
        fopen=open(self.filename,"r")
        data=fopen.read()
        print("Data in file is ",data)

def main():
    print("Enter the Name of file")
    filename=input()
    sobj=stud(filename)
    sobj.Student()
    
if  __name__=="__main__":
    main()