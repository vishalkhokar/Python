import os
class CopyPaste:
    def __init__(self,filename):
        self.filename=filename
    def Copy(self):
        print("Enter the Filename in which COntent has to be Copied")
        des=input()
        
        fopen=open(self.filename,"r")
        data=fopen.read()
          
        fopen2=open(des,"w")
        data1=fopen2.write(data)
        
        fopen2=open(des,"r")
        one=fopen2.read()
        print(one)       
def main():
    print("Enter the Filename which is to be copied")
    filename=input()
    ret=os.path.exists(filename)
    if ret:
        cpobj=CopyPaste(filename)
        cpobj.Copy()
        
    else:
        print("No Such File")    
if __name__=="__main__":
    main()