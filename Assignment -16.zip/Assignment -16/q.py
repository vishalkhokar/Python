import re

class ReadDisplay:
    def __init__(self, filename):
        self.filename = filename

    def read(self):
        # Step 1: Write data to file
        with open(self.filename, "w") as f:
            print("Enter 4 lines of data (e.g., Name and Marks):")
            for i in range(4):
                data = input(f"Line {i+1}: ")
                f.write(data + "\n")

        # Step 2: Read and display full content
        with open(self.filename, "r") as f:
            data2 = f.read()
            print("\nData in file is:\n", data2)

        # Step 3: Find and display students with marks > 75
        result_lines = []
        with open(self.filename, "r") as f:
            lines = f.readlines()
            for line in lines:
                tokens = re.split(r'[\n\s]+', line)
                for token in tokens:
                    if token.isdigit() and int(token) > 75:
                        result_lines.append(line)
                        break  # No need to check other tokens in the same line

        print("Students with marks more than 75:")
        for line in result_lines:
            print(line.strip())

def main():
    filename = input("Enter the filename to write: ")
    obj = ReadDisplay(filename)
    obj.read()

if __name__ == "__main__":
    main()
