import re
class readdisplay:
    def __init__(self,filename):
        self.filename=filename
        
    def read(self):
        fopen=open(self.filename,"w")
        print("Enter the Number")
        i=1
        while(i<5):
            data=input()    
            data=fopen.write(data + "\n")
            i=i+1  
   
        fopen=open(self.filename,"r")     
        data2=fopen.read()
        print("data in File is \n",data2)
        print() 
        fopen=open(self.filename,"r")     
        data2=fopen.readlines()
        newStr=""
        for i in data2:
            k =re.split(r'[\n\s]+',i)
            for j in k:
                temp=j
                if j.isdigit():
                    temp=int(temp)
                    j=int(j)
                    if j>75:
                        newStr=newStr + i
        print("Student with more then 75 marks is ")            
        print(newStr)
def main():
    print("Enter the Filename which has to be write")
    filename=input()
    robj=readdisplay(filename)
    robj.read()
if __name__=="__main__":
    main()