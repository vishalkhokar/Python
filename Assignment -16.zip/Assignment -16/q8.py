class Blankline:
    def __init__(self,filename):
        self.filename=filename
        
    def removeCopy(self): 
        fopen=open(self.filename,"r")
        data3=fopen.readlines()
        icnt=0
        
        print("Please enter the name of Second")
        fielname2=input()
    
        for i in data3:
            print("I m in")
            if i=="\n":
                fopen=open(fielname2,"a")
                data4=fopen.write(i.strip())
            else:
                print("I m in")   
                fopen=open(fielname2,"a")
                data4=fopen.write(i)
                     
        fopen=open(fielname2,"r")
        data3=fopen.readlines()           

def main():
    print("Enter the Name of file")
    filename=input()
    fopen=open(filename,"w")
    print("Enter the content in the file ")
    i=1
    while(i<5):
        data1=input()
        data2=fopen.write(data1 +"\n")
        i=i+1
          
    cobj=Blankline(filename)
    cobj.removeCopy()
if __name__=="__main__":
    main()