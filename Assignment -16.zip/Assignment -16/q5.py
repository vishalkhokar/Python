import os
class readdisplay:
    def __init__(self,filename):
        self.filename=filename
    def read(self):
        try:
            
            fopen=open(self.filename,"r")
            data=fopen.readlines()
            for i in data:
                k=i.split(" ")
                iCnt=0
                for j in k:
                    iCnt=iCnt+1
                if iCnt>=5:
                  print(i)      
                     
        except FileNotFoundError as f:
            print("No Such file found") 
def main():
    print("Enter the Filename which has to be read")
    filename=input()
    ret=os.path.exists(filename)
    if ret:
        robj=readdisplay(filename)
        robj.read()
    else:
        print("No Such file")
if __name__=="__main__":
    main()